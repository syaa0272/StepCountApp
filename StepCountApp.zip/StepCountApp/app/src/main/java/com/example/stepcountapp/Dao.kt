package com.example.stepcountapp

import androidx.room.*

@Dao
interface StepDao {
    @Insert
    suspend fun insert(stepEntry: StepEntry)

    @Query("SELECT * FROM StepEntry ORDER BY timestamp DESC")
    suspend fun getAll(): List<StepEntry>
}
